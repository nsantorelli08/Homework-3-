import numpy as np

def getData(filename='input.txt'):
    return np.loadtxt(filename)
